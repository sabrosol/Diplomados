# ucat-git-01
Prueba git en grupo <br>
TAREAS: <br>
juanmanuelsilva -> Crea un archivo index.html con la estructura html <br>
yeins -> Insertar en index.html la etiqueta "head" con links a los archivos de main.js y style.css <br>
Angel-Alf -> Insertar en index.html dentro de body una div "header" con botonera 5 botones (inicio, empresa, productos, servicios, contacto). Use links # <br>
harritsson -> Insertar en index.html una div con id "content" y class "content" con 3 divs con contenidos lorem ipsum dentro de etiquetas PARRAFO<br>
sabrosol ->  Insertar en index.html una div con id "footer" y class "footer" con nombre de emmpresa ficticio, telefono y direccion<br>
JANSSEN HERNÁNDEZ -> NO TENGO EL USUARIO GIT<BR>

